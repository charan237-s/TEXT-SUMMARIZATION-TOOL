import React from 'react';
import { SummaryResult as SummaryResultType } from '../types';
import { Download, Copy, CheckCircle, Zap, Target, Hash } from 'lucide-react';

interface SummaryResultProps {
  result: SummaryResultType;
  onDownload: () => void;
}

export default function SummaryResult({ result, onDownload }: SummaryResultProps) {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(result.summary);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const compressionPercentage = Math.round((1 - result.compressionRatio) * 100);

  return (
    <div className="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Zap className="mr-2" size={20} />
          Summary Generated
        </h3>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <Target className="mx-auto mb-2 text-blue-600" size={16} />
            <div className="text-lg font-bold text-blue-700">{result.summaryLength}</div>
            <div className="text-xs text-blue-600">Summary Words</div>
          </div>
          
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <Hash className="mx-auto mb-2 text-green-600" size={16} />
            <div className="text-lg font-bold text-green-700">{compressionPercentage}%</div>
            <div className="text-xs text-green-600">Compression</div>
          </div>
          
          <div className="text-center p-3 bg-purple-50 rounded-lg">
            <CheckCircle className="mx-auto mb-2 text-purple-600" size={16} />
            <div className="text-lg font-bold text-purple-700">{result.keyPhrases.length}</div>
            <div className="text-xs text-purple-600">Key Phrases</div>
          </div>
        </div>

        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Generated Summary:</h4>
          <div className="bg-gray-50 rounded-lg p-4 border-l-4 border-blue-500">
            <p className="text-gray-800 leading-relaxed">{result.summary}</p>
          </div>
        </div>

        <div className="mb-6">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Key Phrases:</h4>
          <div className="flex flex-wrap gap-2">
            {result.keyPhrases.map((phrase, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 text-sm rounded-full border border-blue-200"
              >
                {phrase}
              </span>
            ))}
          </div>
        </div>

        <div className="flex space-x-3">
          <button
            onClick={handleCopy}
            className="flex-1 flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            {copied ? (
              <>
                <CheckCircle size={16} className="mr-2" />
                Copied!
              </>
            ) : (
              <>
                <Copy size={16} className="mr-2" />
                Copy Summary
              </>
            )}
          </button>
          
          <button
            onClick={onDownload}
            className="flex-1 flex items-center justify-center px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200"
          >
            <Download size={16} className="mr-2" />
            Download
          </button>
        </div>
      </div>
    </div>
  );
}