export interface SummaryOptions {
  length: 'short' | 'medium' | 'detailed';
  maxSentences?: number;
  minSentenceLength?: number;
}

export interface TextAnalysis {
  wordCount: number;
  sentenceCount: number;
  readabilityScore: number;
  averageWordsPerSentence: number;
}

export interface SummaryResult {
  summary: string;
  originalLength: number;
  summaryLength: number;
  compressionRatio: number;
  keyPhrases: string[];
}