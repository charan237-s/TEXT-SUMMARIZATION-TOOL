import React, { useCallback } from 'react';
import { Upload, FileText } from 'lucide-react';

interface FileUploaderProps {
  onFileContent: (content: string, filename: string) => void;
  disabled?: boolean;
}

export default function FileUploader({ onFileContent, disabled }: FileUploaderProps) {
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.includes('text') && !file.name.endsWith('.txt')) {
      alert('Please upload a text file (.txt)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      onFileContent(content, file.name);
    };
    reader.readAsText(file);
  }, [onFileContent]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const files = Array.from(e.dataTransfer.files);
    const textFile = files.find(file => file.type.includes('text') || file.name.endsWith('.txt'));
    
    if (textFile) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        onFileContent(content, textFile.name);
      };
      reader.readAsText(textFile);
    }
  }, [onFileContent]);

  return (
    <div
      className={`border-2 border-dashed border-gray-300 rounded-lg p-6 text-center transition-all duration-200 ${
        disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-blue-400 hover:bg-blue-50/50 cursor-pointer'
      }`}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <input
        type="file"
        accept=".txt,text/plain"
        onChange={handleFileUpload}
        disabled={disabled}
        className="hidden"
        id="file-upload"
      />
      <label htmlFor="file-upload" className={`cursor-pointer ${disabled ? 'cursor-not-allowed' : ''}`}>
        <div className="flex flex-col items-center space-y-2">
          <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full text-white">
            <Upload size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-700">Upload a text file</p>
            <p className="text-xs text-gray-500">Drag and drop or click to browse</p>
          </div>
          <div className="flex items-center space-x-1 text-xs text-gray-400">
            <FileText size={12} />
            <span>Supports .txt files</span>
          </div>
        </div>
      </label>
    </div>
  );
}