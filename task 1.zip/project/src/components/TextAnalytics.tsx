import React from 'react';
import { TextAnalysis } from '../types';
import { BarChart3, Clock, BookOpen, TrendingUp } from 'lucide-react';

interface TextAnalyticsProps {
  analysis: TextAnalysis | null;
}

export default function TextAnalytics({ analysis }: TextAnalyticsProps) {
  if (!analysis) return null;

  const getReadabilityLevel = (score: number): { level: string; color: string } => {
    if (score >= 90) return { level: 'Very Easy', color: 'text-green-600' };
    if (score >= 80) return { level: 'Easy', color: 'text-green-500' };
    if (score >= 70) return { level: 'Fairly Easy', color: 'text-yellow-500' };
    if (score >= 60) return { level: 'Standard', color: 'text-orange-500' };
    if (score >= 50) return { level: 'Fairly Difficult', color: 'text-red-500' };
    return { level: 'Difficult', color: 'text-red-600' };
  };

  const readability = getReadabilityLevel(analysis.readabilityScore);

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
        <BarChart3 className="mr-2 text-blue-600" size={20} />
        Text Analytics
      </h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center p-3 bg-blue-50 rounded-lg">
          <div className="flex items-center justify-center mb-2">
            <BookOpen className="text-blue-600" size={16} />
          </div>
          <div className="text-2xl font-bold text-blue-700">{analysis.wordCount.toLocaleString()}</div>
          <div className="text-xs text-blue-600">Words</div>
        </div>
        
        <div className="text-center p-3 bg-purple-50 rounded-lg">
          <div className="flex items-center justify-center mb-2">
            <Clock className="text-purple-600" size={16} />
          </div>
          <div className="text-2xl font-bold text-purple-700">{analysis.sentenceCount}</div>
          <div className="text-xs text-purple-600">Sentences</div>
        </div>
        
        <div className="text-center p-3 bg-green-50 rounded-lg">
          <div className="flex items-center justify-center mb-2">
            <TrendingUp className="text-green-600" size={16} />
          </div>
          <div className="text-2xl font-bold text-green-700">{Math.round(analysis.averageWordsPerSentence)}</div>
          <div className="text-xs text-green-600">Avg Words/Sentence</div>
        </div>
        
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <div className="text-lg font-bold text-gray-700">{Math.round(analysis.readabilityScore)}</div>
          <div className={`text-xs font-medium ${readability.color}`}>{readability.level}</div>
          <div className="text-xs text-gray-500">Readability</div>
        </div>
      </div>
    </div>
  );
}