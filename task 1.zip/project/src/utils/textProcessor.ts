import { SummaryOptions, TextAnalysis, SummaryResult } from '../types';

export class TextProcessor {
  private static stopWords = new Set([
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
    'by', 'as', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
    'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can',
    'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
    'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'her', 'its', 'our', 'their'
  ]);

  static analyzeText(text: string): TextAnalysis {
    const sentences = this.splitIntoSentences(text);
    const words = this.extractWords(text);
    
    return {
      wordCount: words.length,
      sentenceCount: sentences.length,
      readabilityScore: this.calculateReadabilityScore(sentences, words),
      averageWordsPerSentence: words.length / sentences.length || 0
    };
  }

  static summarizeText(text: string, options: SummaryOptions): SummaryResult {
    const sentences = this.splitIntoSentences(text);
    const words = this.extractWords(text);
    
    if (sentences.length <= 3) {
      return {
        summary: text,
        originalLength: words.length,
        summaryLength: words.length,
        compressionRatio: 1,
        keyPhrases: this.extractKeyPhrases(text)
      };
    }

    const sentenceScores = this.scoreSentences(sentences, text);
    const targetSentences = this.getTargetSentenceCount(sentences.length, options.length);
    
    const topSentences = sentenceScores
      .sort((a, b) => b.score - a.score)
      .slice(0, targetSentences)
      .sort((a, b) => a.index - b.index)
      .map(item => item.sentence);

    const summary = topSentences.join(' ');
    const summaryWords = this.extractWords(summary);

    return {
      summary,
      originalLength: words.length,
      summaryLength: summaryWords.length,
      compressionRatio: summaryWords.length / words.length,
      keyPhrases: this.extractKeyPhrases(text)
    };
  }

  private static splitIntoSentences(text: string): string[] {
    return text
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 10);
  }

  private static extractWords(text: string): string[] {
    return text
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2 && !this.stopWords.has(word));
  }

  private static scoreSentences(sentences: string[], fullText: string) {
    const wordFreq = this.calculateWordFrequency(fullText);
    
    return sentences.map((sentence, index) => {
      const words = this.extractWords(sentence);
      const score = words.reduce((sum, word) => sum + (wordFreq[word] || 0), 0) / words.length;
      
      // Boost score for sentences at the beginning or end
      const positionBoost = index < 2 || index >= sentences.length - 2 ? 1.2 : 1;
      
      return {
        sentence,
        score: score * positionBoost,
        index
      };
    });
  }

  private static calculateWordFrequency(text: string): Record<string, number> {
    const words = this.extractWords(text);
    const frequency: Record<string, number> = {};
    
    words.forEach(word => {
      frequency[word] = (frequency[word] || 0) + 1;
    });

    // Normalize frequencies
    const maxFreq = Math.max(...Object.values(frequency));
    Object.keys(frequency).forEach(word => {
      frequency[word] = frequency[word] / maxFreq;
    });

    return frequency;
  }

  private static getTargetSentenceCount(totalSentences: number, length: string): number {
    switch (length) {
      case 'short':
        return Math.max(1, Math.floor(totalSentences * 0.2));
      case 'medium':
        return Math.max(2, Math.floor(totalSentences * 0.4));
      case 'detailed':
        return Math.max(3, Math.floor(totalSentences * 0.6));
      default:
        return Math.max(2, Math.floor(totalSentences * 0.3));
    }
  }

  private static extractKeyPhrases(text: string): string[] {
    const words = this.extractWords(text);
    const frequency = this.calculateWordFrequency(text);
    
    return Object.entries(frequency)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 8)
      .map(([word]) => word);
  }

  private static calculateReadabilityScore(sentences: string[], words: string[]): number {
    const avgWordsPerSentence = words.length / sentences.length || 0;
    const avgSyllablesPerWord = words.reduce((sum, word) => sum + this.countSyllables(word), 0) / words.length || 0;
    
    // Simplified Flesch Reading Ease formula
    return Math.max(0, Math.min(100, 206.835 - (1.015 * avgWordsPerSentence) - (84.6 * avgSyllablesPerWord)));
  }

  private static countSyllables(word: string): number {
    return word.toLowerCase().replace(/[^aeiouy]/g, '').length || 1;
  }
}